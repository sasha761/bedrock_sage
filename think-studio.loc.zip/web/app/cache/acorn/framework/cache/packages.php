<?php return array (
  'log1x/acf-composer' => 
  array (
    'providers' => 
    array (
      0 => 'Log1x\\AcfComposer\\Providers\\AcfComposerServiceProvider',
    ),
  ),
  'log1x/sage-directives' => 
  array (
    'providers' => 
    array (
      0 => 'Log1x\\SageDirectives\\SageDirectivesServiceProvider',
    ),
  ),
  'nesbot/carbon' => 
  array (
    'providers' => 
    array (
      0 => 'Carbon\\Laravel\\ServiceProvider',
    ),
  ),
  'nunomaduro/termwind' => 
  array (
    'providers' => 
    array (
      0 => 'Termwind\\Laravel\\TermwindServiceProvider',
    ),
  ),
  'roots/sage' => 
  array (
    'providers' => 
    array (
      0 => 'App\\Providers\\ThemeServiceProvider',
    ),
  ),
);