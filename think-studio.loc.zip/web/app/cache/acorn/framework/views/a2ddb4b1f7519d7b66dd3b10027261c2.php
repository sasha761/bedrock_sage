<div class="page-header">
  <h1><?php echo $title; ?></h1>
</div>
<?php /**PATH C:\OSPanel\home\think-studio.loc\web\app\themes\news\resources\views/partials/page-header.blade.php ENDPATH**/ ?>