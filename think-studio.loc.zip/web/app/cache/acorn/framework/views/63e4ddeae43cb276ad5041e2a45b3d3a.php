<script type="text/javascript">
  acf.addFilter('acf_blocks_parse_node_attr', (current, node) => node.name.startsWith('x-') ? node : current);
</script>
<?php /**PATH C:\OSPanel\home\think-studio.loc\web\app\themes\news\vendor\log1x\acf-composer\src\Providers/../../resources/views/alpine-support.blade.php ENDPATH**/ ?>