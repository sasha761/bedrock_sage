<nav class="c-menu">
  <?php if($menuParents->isNotEmpty()): ?>
  <div class="is-first-col">
    <ul class="c-menu__list">
      <?php $__currentLoopData = $menuParents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
          $parentId = (string) $parent->db_id;
          $hasChild = $menuChildren->has($parentId);
        ?>
        <li class="c-menu__item <?php echo e($hasChild ? 'has-child' : ''); ?>" data-has-child="<?php echo e($parentId); ?>">
          <a href="<?php echo e($parent->url); ?>"><?php echo e($parent->title); ?></a>
          <?php if($hasChild): ?>
            <svg width="6px" height="11px">
              <use xlink:href="#arrow-icon"></use>
            </svg>
          <?php endif; ?>
        </li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
  </div>
  <?php endif; ?>

  <?php if($menuChildren->isNotEmpty()): ?>
    <div class="is-second-col">
      <?php $__currentLoopData = $menuChildren; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parentId => $childItems): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <ul class="c-menu__child" data-id="<?php echo e($parentId); ?>">
          <?php $__currentLoopData = $childItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="c-menu__item">
              <a href="<?php echo e($child->url); ?>"><?php echo e($child->title); ?></a>
            </li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  <?php endif; ?>

  <?php if($menuImage): ?>
    <div class="is-third-col">
      <img src="<?php echo $menuImage; ?>" alt="">
    </div>
  <?php endif; ?>
</nav>
<?php /**PATH C:\OSPanel\home\think-studio.loc\web\app\themes\news\resources\views/partials/menu.blade.php ENDPATH**/ ?>