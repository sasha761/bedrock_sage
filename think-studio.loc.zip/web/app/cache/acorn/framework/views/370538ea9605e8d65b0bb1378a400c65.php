<?php (dynamic_sidebar('sidebar-primary')); ?>
<?php /**PATH C:\OSPanel\home\think-studio.loc\web\app\themes\news\resources\views/sections/sidebar.blade.php ENDPATH**/ ?>