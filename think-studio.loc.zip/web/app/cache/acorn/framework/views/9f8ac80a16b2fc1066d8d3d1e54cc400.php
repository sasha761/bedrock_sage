<div style="display: inline-block; position: absolute; z-index: -1; display: none;">
  <svg xmlns="http://www.w3.org/2000/svg">
    <symbol id="arrow-icon" viewBox="0 0 6 11" >
      <path d="M5.58203 6.04883L1.83203 9.79883C1.56836 10.0625 1.1582 10.1504 0.806641 10.0039C0.455078 9.85742 0.220703 9.50586 0.220703 9.125V1.625C0.220703 1.24414 0.455078 0.921875 0.806641 0.775391C1.1582 0.628906 1.56836 0.716797 1.83203 0.980469L5.58203 4.73047C5.96289 5.08203 5.96289 5.69727 5.58203 6.04883Z" />
    </symbol>
  </svg>
</div><?php /**PATH C:\OSPanel\home\think-studio.loc\web\app\themes\news\resources\views/partials/icons.blade.php ENDPATH**/ ?>