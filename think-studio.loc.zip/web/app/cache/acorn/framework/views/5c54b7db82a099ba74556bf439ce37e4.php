<form role="search" method="get" class="c-search" action="<?php echo e(home_url('/')); ?>">
  <input 
    type="search" 
    class="c-input" 
    placeholder="<?php echo esc_attr_x('Search for a product', 'placeholder', 'sage'); ?>" 
    name="s"
    value="<?php echo e(get_search_query()); ?>"
  >
</form><?php /**PATH C:\OSPanel\home\think-studio.loc\web\app\themes\news\resources\views/forms/search.blade.php ENDPATH**/ ?>