<?php
  // Получаем меню по location "mega_menu"
  $locations = get_nav_menu_locations();
  $menu = $locations['primary_navigation'] ?? null;

  $menuItems = [];
  if ($menu) {
    $menuObj = wp_get_nav_menu_object($menu);
    $menuItems = wp_get_nav_menu_items($menuObj->term_id) ?: [];
  }
?>

<nav class="c-menu">
  <ul class="c-menu__list">
    <?php $__currentLoopData = $menuItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <li class="c-menu__item">
        <a href="<?php echo e($item->url); ?>">
          <?php echo e($item->title); ?>

        </a>
        
      </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </ul>
</nav>
<?php /**PATH C:\OSPanel\home\think-studio.loc\web\app\themes\news\resources\views/partials/mega-menu.blade.php ENDPATH**/ ?>