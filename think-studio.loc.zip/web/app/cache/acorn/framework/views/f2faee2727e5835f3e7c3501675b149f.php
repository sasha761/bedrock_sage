<header class="l-header">
  <div class="l-header__top">
    <div class="u-container">
      <div class="l-header__top-flex">
        <a class="c-logo" href="#">
          <img src="<?= \Roots\asset('images/logo.svg'); ?>">
        </a>

        <?php echo $__env->make('forms.search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <a href="#" class="c-user">
          <img src="<?= \Roots\asset('images/user.svg'); ?>">
        </a>
        
        <a href="#" class="u-btn is-purple is-cart">
          <img src="<?= \Roots\asset('images/cart.svg'); ?>">
          <span class="c-price">£0.00</span>
        </a>
      </div>
    </div>
  </div>
  <div class="l-header__bottom">
    <div class="u-container">
      <button class="js-menu-btn">
        <img src="<?= \Roots\asset('images/burger-icon.svg'); ?>">
        <span>Products</span>
      </button>
    </div>
  </div>
  <div class="l-header__menu">
    <div class="u-container">
      <?php if(has_nav_menu('primary_navigation')): ?>
        <?php echo $__env->make('partials.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <?php endif; ?>
      
      <?php echo $__env->make('forms.search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
  </div>
</header>
<?php /**PATH C:\OSPanel\home\think-studio.loc\web\app\themes\news\resources\views/sections/header.blade.php ENDPATH**/ ?>