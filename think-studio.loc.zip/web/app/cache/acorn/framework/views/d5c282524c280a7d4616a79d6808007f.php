<footer class="content-info">
  <!-- <?php (dynamic_sidebar('sidebar-footer')); ?> -->
</footer>
<?php /**PATH C:\OSPanel\home\think-studio.loc\web\app\themes\news\resources\views/sections/footer.blade.php ENDPATH**/ ?>